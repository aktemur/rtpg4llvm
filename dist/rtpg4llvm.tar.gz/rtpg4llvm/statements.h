/*
 *  statements.h
 *  codeGenFrameWork
 *
 *  Created by umit on 12/12/11.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */
#ifndef _STATEMENTS
#define _STATEMENTS

#include "breakStmt.h"
#include "continueStmt.h"
#include "declarationStmt.h"
#include "emptyStmt.h"
#include "exprStmt.h"
#include "ifElseStmt.h"
#include "returnStmt.h"
#include "seqStmt.h"
#include "whileStmt.h"

#endif