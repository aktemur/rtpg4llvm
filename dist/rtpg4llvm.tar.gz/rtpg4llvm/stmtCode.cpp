//
//  stmtCode.cpp
//  codeGenFrameWork
//
//  Created by Baris Aktemur on 12.08.2012.
//  Copyright (c) 2012 2011 Ozyegin University. All rights reserved.
//

#include "stmtCode.h"

using namespace codeGen;

StmtCode::~StmtCode() {}

void StmtCode::indent(int level) {
  for(int i=0; i < level; ++i) {
    std::cout << " ";
  }
}

void StmtCode::print() {
  print(0);
}