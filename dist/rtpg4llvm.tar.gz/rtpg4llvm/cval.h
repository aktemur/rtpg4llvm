/*
 *  cval.h
 *  codeGenFrameWork
 *
 *  Created by umit on 12/11/11.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */
#ifndef _CVAL
#define _CVAL

#include "llvm/DerivedTypes.h"

namespace codeGen {

// In C we need to distinguish signed and unsigned stuff
struct cval {
   bool is_signed;
   llvm::Value* val;
};

cval _make_signed(llvm::Value *val);

cval _make_unsigned(llvm::Value *val);

cval make_cval(bool is_signed, llvm::Value *val);

}

#endif