/*
 *  Unit.h
 *  codeGenFrameWork
 *
 *  Created by umit on 1/7/12.
 *  Copyright 2012 2011 Ozyegin University. All rights reserved.
 *
 */

#ifndef _COMPILE_UNIT_
#define _COMPILE_UNIT_

#include "codeGeneration.h"
#include "llvm/PassManager.h"
#include <vector>
#include <iostream>

namespace codeGen {

class CompileUnit : public CodeGeneration {
public:
   virtual ~CompileUnit();
   virtual void build() = 0;
   virtual void print() = 0;
   virtual void compile();
   virtual void compileAndDump();
   virtual void compile(unsigned optLevel);
   virtual void compileAndDump(unsigned optLevel);
   virtual void readUserDefinedModule(string InputFile);
protected:
  static void compile(vector<CompileUnit*> *c);
  static void addOptimizationPasses(llvm::PassManagerBase &MPM, llvm::FunctionPassManager &FPM,
                                                 unsigned OptLevel); 
  static void populateFunctionPassManager(llvm::FunctionPassManager &FPM, unsigned OptLevel); 
  static void populateModulePassManager(llvm::PassManagerBase &FPM, unsigned OptLevel); 

};

}

#endif
