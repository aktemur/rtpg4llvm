/*
 *  logicalNotExpr.h
 *  codeGenFrameWork
 *
 *  Created by umit on 1/1/12.
 *  Copyright 2012 2011 Ozyegin University. All rights reserved.
 *
 */

#ifndef _LOGICAL_NOT_EXPR_
#define _LOGICAL_NOT_EXPR_

#include "exprCode.h"

namespace codeGen {

class LogicalNotExpr : public ExprCode {
  ExprCode* exp;
public:
  LogicalNotExpr(ExprCode* exp) :
  exp(exp) {
  }
  ~LogicalNotExpr();
  
  virtual cval build();
  virtual void print();
};

}

#endif