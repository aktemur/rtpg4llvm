//
//  compileUnit.cpp
//  codeGenFrameWork
//
//  Created by Baris Aktemur on 31.05.2012.
//  Copyright (c) 2012 2011 Ozyegin University. All rights reserved.
//

#include "compileUnit.h"
#include "llvm/PassManager.h"
#include "llvm/Support/TargetSelect.h"
#include "llvm/Analysis/Verifier.h"
#include "llvm/Target/TargetData.h"
#include "llvm/Target/TargetLibraryInfo.h"
#include "llvm/Transforms/IPO/PassManagerBuilder.h"
#include "llvm/LinkAllPasses.h"
#include "llvm/ADT/Triple.h"
#include <llvm/Support/MemoryBuffer.h>
#include <llvm/Bitcode/ReaderWriter.h>
#include <llvm/Support/system_error.h>

#include "llvm/DefaultPasses.h"
#include "llvm/Analysis/Passes.h"
#include "llvm/Support/CommandLine.h"
#include "llvm/Transforms/Scalar.h"
#include "llvm/Transforms/Vectorize.h"
#include "llvm/Transforms/IPO.h"
#include "llvm/ADT/SmallVector.h"
#include "llvm/Support/ManagedStatic.h"

using namespace codeGen;

CompileUnit::~CompileUnit() {}

void CompileUnit::readUserDefinedModule(string InputFile)
{
  llvm::Module *testModule = NULL;
  string ErrorMsg;
  llvm::OwningPtr<llvm::MemoryBuffer> BufferPtr;
  llvm::error_code err_code = llvm::MemoryBuffer::getFileOrSTDIN(InputFile.c_str(), BufferPtr);
  
  testModule = llvm::getLazyBitcodeModule(BufferPtr.get(), llvm::getGlobalContext());
  if (testModule == NULL)
    cout << "error module creation" << endl;
  
//  if (eeng == NULL)
//    cout << "hata execution engine " << endl;
  
//  cout << "getting main function1" << endl;
//  llvm::Function *f= testModule->getFunction("main");
//  cout << "getting get struct type" << endl;
//  testModule->getTypeByName("deneme");
//  llvm::GlobalVariable* var = testModule->getGlobalVariable("bar");
//  llvm::Type *structTest = testModule->getTypeByName("struct.deneme");
//  llvm::StructType *structTypeTest = (llvm::StructType *) structTest;
  
//  cout << structTypeTest->getNumElements() << endl;
//  cout<<endl;

}

void CompileUnit::compile() {
  vector<CompileUnit*> units;
  units.push_back(this);
  CompileUnit::compile(&units);
}

void CompileUnit::compileAndDump() {
  compile();
  CodeGeneration::TheModule->dump();
}

void CompileUnit::compileAndDump(unsigned optLevel) {
  compile(optLevel);
  CodeGeneration::TheModule->dump();
}

void CompileUnit::compile(vector<CompileUnit*> *c) {
  CodeGeneration::codeGenerationInit();
  
  BuilderT* B = new llvm::IRBuilder<>(llvm::getGlobalContext());
  CodeGeneration::Builder = B;  
  CodeGeneration::C = &llvm::getGlobalContext();  
  CodeGeneration::env = new scope();
  
  for (typeof(c->begin())unit = c->begin(); unit != c->end(); ++unit) {
    (*unit)->build();           
  }

  verifyModule(*CodeGeneration::TheModule, llvm::PrintMessageAction);  
}

// This method is copied and adapted from opt.cpp
void CompileUnit::compile(unsigned optLevel) {  
  compile();
  
  // Initialize passes
  llvm::PassRegistry &Registry = *llvm::PassRegistry::getPassRegistry();
  llvm::initializeCore(Registry);
  llvm::initializeScalarOpts(Registry);
  llvm::initializeVectorization(Registry);
  llvm::initializeIPO(Registry);
  llvm::initializeAnalysis(Registry);
  llvm::initializeIPA(Registry);
  llvm::initializeTransformUtils(Registry);
  llvm::initializeInstCombine(Registry);
  llvm::initializeInstrumentation(Registry);
  llvm::initializeTarget(Registry);
  
  // Create a PassManager to hold and optimize the collection of passes we are
  // about to build.
  //
  llvm::PassManager Passes;
  llvm::FunctionPassManager FPasses(CodeGeneration::TheModule);
  
  // Add an appropriate TargetLibraryInfo pass for the module's triple.
  llvm::TargetLibraryInfo *TLI = new llvm::TargetLibraryInfo(llvm::Triple(CodeGeneration::TheModule->getTargetTriple()));
  Passes.add(TLI);
  
  // Add an appropriate TargetData instance for this module.
  llvm::TargetData *TD = (llvm::TargetData *)CodeGeneration::TheExecutionEngine->getTargetData();
  if (TD) {
    Passes.add(new llvm::TargetData(*TD));
    FPasses.add(new llvm::TargetData(*TD));
  }
  
  addOptimizationPasses(Passes, FPasses, optLevel);
  
  if (optLevel > 0) {
    FPasses.doInitialization();
    for (llvm::Module::iterator F = CodeGeneration::TheModule->begin(), E = CodeGeneration::TheModule->end(); F != E; ++F)
      FPasses.run(*F);
    FPasses.doFinalization();
  }

  // Now that we have all of the passes ready, run them.
  Passes.run(*CodeGeneration::TheModule);
}

// This method is copied and adapted from opt.cpp
void CompileUnit::addOptimizationPasses(llvm::PassManagerBase &MPM, llvm::FunctionPassManager &FPM,
                                  unsigned OptLevel) {
  llvm::PassManagerBuilder Builder;
  Builder.OptLevel = OptLevel;
  
  if (OptLevel > 1) {
    unsigned Threshold = 225;
    if (OptLevel > 2)
      Threshold = 275;
    Builder.Inliner = llvm::createFunctionInliningPass(Threshold);
  } else {
    Builder.Inliner = llvm::createAlwaysInlinerPass();
  }
  Builder.DisableUnitAtATime = false;
  Builder.DisableUnrollLoops = OptLevel == 0;
  Builder.DisableSimplifyLibCalls = false;

  populateFunctionPassManager(FPM, OptLevel);
  populateModulePassManager(MPM, OptLevel);
}

void CompileUnit::populateFunctionPassManager(llvm::FunctionPassManager &FPM, unsigned OptLevel) {
  //addExtensionsToPM(EP_EarlyAsPossible, FPM);
  if (OptLevel == 0) return;
  
  FPM.add(llvm::createScalarReplAggregatesPass());
  FPM.add(llvm::createEarlyCSEPass());
}

void CompileUnit::populateModulePassManager(llvm::PassManagerBase &MPM, unsigned OptLevel) {
  //addInitialAliasAnalysisPasses(MPM);

  MPM.add(llvm::createBasicAliasAnalysisPass());
  MPM.add(llvm::createInstructionCombiningPass());
  MPM.add(llvm::createCFGSimplificationPass());
  MPM.add(llvm::createAlwaysInlinerPass());
  MPM.add(llvm::createFunctionAttrsPass());
  MPM.add(llvm::createTailCallEliminationPass());
  MPM.add(llvm::createLoopRotatePass());
  MPM.add(llvm::createIndVarSimplifyPass());
  MPM.add(llvm::createLoopIdiomPass());
  MPM.add(llvm::createLoopDeletionPass());
  MPM.add(llvm::createLoopUnrollPass());
  //  MPM.add(llvm::createGVNPass());
  MPM.add(llvm::createDeadStoreEliminationPass());
  MPM.add(llvm::createInstructionCombiningPass());
  MPM.add(llvm::createDeadStoreEliminationPass());
  MPM.add(llvm::createCFGSimplificationPass());
  MPM.add(llvm::createGlobalDCEPass());
}
