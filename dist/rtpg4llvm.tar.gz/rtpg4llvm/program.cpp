//
//  program.cpp
//  codeGenFrameWork
//
//  Created by Baris Aktemur on 31.05.2012.
//  Copyright (c) 2012 2011 Ozyegin University. All rights reserved.
//

#include "program.h"

using namespace codeGen;

Program::~Program() {
  for (typeof(units->begin())s = units->begin(); s != units->end(); ++s) {
    delete (*s);
  }
  delete units;
}

void Program::build() {
  for (typeof(units->begin())s = units->begin(); s != units->end(); ++s) {
    (*s)->build();
  }
}

void Program::compile() {
  CompileUnit::compile(units);
}

void Program::print() {
  for (typeof(units->begin())s = units->begin(); s != units->end(); ++s) {
    (*s)->print();
  }
}
