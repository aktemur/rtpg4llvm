/*
 *  lessThenExpr.cpp
 *  codeGenFrameWork
 *
 *  Created by umit on 12/21/11.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */

#include "greaterThanEqExpr.h"

using namespace codeGen;

llvm::Value* GreaterThanEqExpr::integerOp(llvm::Value* lval, llvm::Value* rval, bool isSigned) 
{
    if (isSigned) {
        return Builder->CreateICmpSGE(lval, rval);
    } else {
        return Builder->CreateICmpUGE(lval, rval);
    }
}

llvm::Value* GreaterThanEqExpr::fpOp(llvm::Value* lval, llvm::Value* rval) 
{
    return Builder->CreateFCmpOGE(lval, rval);
}

void GreaterThanEqExpr::printOp() {
  std::cout << " >= ";
}