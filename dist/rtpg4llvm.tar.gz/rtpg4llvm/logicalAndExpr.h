/*
 *  logicalAndExpr.h
 *  codeGenFrameWork
 *
 *  Created by umit on 12/25/11.
 *  Copyright 2011 2011 Ozyegin University. All rights reserved.
 *
 */

#ifndef _LOGICAL_AND_EXPR_
#define _LOGICAL_AND_EXPR_

#include "logicalExpr.h"

namespace codeGen {

class LogicalAndExpr : public LogicalExpr {
public:
   LogicalAndExpr(ExprCode* lhs, ExprCode* rhs) :
   LogicalExpr(lhs, rhs) {
   }
   
   virtual llvm::Value* integerOp(llvm::Value* lval, llvm::Value* rval);
   virtual void printOp();
};

}

#endif