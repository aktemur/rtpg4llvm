//
//  functionParameter.cpp
//  codeGenFrameWork
//
//  Created by Baris Aktemur on 30.05.2012.
//  Copyright (c) 2012 2011 Ozyegin University. All rights reserved.
//

#include "functionParameter.h"

using namespace codeGen;

FuncParam::~FuncParam() {
  delete type;
}

std::string FuncParam::getName() {
  return name;
}

codeGen::Type* FuncParam::getType() {
  return type;
}

bool FuncParam::isRestrict() {
  return restricted;
}

void FuncParam::print() {
  type->print();
  if(restricted) std::cout << " __restrict__ ";
  std::cout << " " << name;
}
