//
//  emptyStmt.cpp
//  codeGenFrameWork
//
//  Created by Baris Aktemur on 13.08.2012.
//  Copyright (c) 2012 2011 Ozyegin University. All rights reserved.
//

#include "emptyStmt.h"

using namespace codeGen;

void EmptyStmt::build() { 
}

void EmptyStmt::print(int level) { 
  indent(level);
  std::cout << " // EMPTY\n";
}

