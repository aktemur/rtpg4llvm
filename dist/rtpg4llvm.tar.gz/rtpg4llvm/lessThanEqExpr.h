/*
 *  lessThenExpr.h
 *  codeGenFrameWork
 *
 *  Created by umit on 12/11/11.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */
#ifndef _LESS_THAN_EQ_EXPR
#define _LESS_THAN_EQ_EXPR

#include "relationalExpr.h"

namespace codeGen {

class LessThanEqExpr : public RelationalExpr {
public:
   LessThanEqExpr(ExprCode * lhs, ExprCode * rhs) :
   RelationalExpr(lhs, rhs) {
   }
    
   virtual llvm::Value* integerOp(llvm::Value* lval, llvm::Value* rval, bool isSigned);
   virtual llvm::Value* fpOp(llvm::Value* lval, llvm::Value* rval);
   virtual void printOp();
};

}

#endif