//
//  exprCode.cpp
//  codeGenFrameWork
//
//  Created by Baris Aktemur on 13.08.2012.
//  Copyright (c) 2012 2011 Ozyegin University. All rights reserved.
//

#include "exprCode.h"

using namespace codeGen;

ExprCode::~ExprCode() {}

cval ExprCode::buildLHS() {
  std::cerr << "This expr is not allowed at LHS." << std::endl;
  exit(1);
}

