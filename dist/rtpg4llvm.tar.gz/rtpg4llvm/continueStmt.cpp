//
//  continueStmt.cpp
//  codeGenFrameWork
//
//  Created by Baris Aktemur on 30.05.2012.
//  Copyright (c) 2012 2011 Ozyegin University. All rights reserved.
//

#include "continueStmt.h"

using namespace codeGen;

void ContinueStmt::build() {
  std::cerr << "Continue stmt not supported yet." << std::endl;
  exit(1);
}

void ContinueStmt::print(int level) {
  indent(level);
  std::cout << "continue;\n";
}