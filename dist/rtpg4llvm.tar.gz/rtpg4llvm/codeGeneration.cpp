//
//  codeGeneration.cpp
//  codeGenFrameWork
//
//  Created by Baris Aktemur on 30.05.2012.
//  Copyright (c) 2012 2011 Ozyegin University. All rights reserved.
//

#include <iostream>
#include "codeGeneration.h"

#include "llvm/TypeBuilder.h"
#include "llvm/Type.h"
#include "llvm/ADT/Triple.h"

#include "llvm/LLVMContext.h"
#include "llvm/Module.h"
#include "llvm/Type.h"
#include "llvm/ADT/Triple.h"
#include "llvm/Bitcode/ReaderWriter.h"
#include "llvm/CodeGen/LinkAllCodegenComponents.h"
#include "llvm/ExecutionEngine/GenericValue.h"
#include "llvm/ExecutionEngine/Interpreter.h"
#include "llvm/ExecutionEngine/JIT.h"
#include "llvm/ExecutionEngine/JITEventListener.h"
#include "llvm/ExecutionEngine/JITMemoryManager.h"
#include "llvm/ExecutionEngine/MCJIT.h"
#include "llvm/Support/CommandLine.h"
#include "llvm/Support/IRReader.h"
#include "llvm/Support/ManagedStatic.h"
#include "llvm/Support/MemoryBuffer.h"
#include "llvm/Support/PluginLoader.h"
#include "llvm/Support/PrettyStackTrace.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/Support/Process.h"
#include "llvm/Support/Signals.h"
#include "llvm/Support/TargetSelect.h"
#include "llvm/Target/TargetData.h"
#include "llvm/Support/DynamicLibrary.h"
#include "llvm/Support/Memory.h"

#ifdef __linux__
// These includes used by LLIMCJITMemoryManager::getPointerToNamedFunction()
// for Glibc trickery. Look comments in this function for more information.
#ifdef HAVE_SYS_STAT_H
#include <sys/stat.h>
#endif
#include <fcntl.h>
#include <unistd.h>
#endif

#ifdef __CYGWIN__
#include <cygwin/version.h>
#if defined(CYGWIN_VERSION_DLL_MAJOR) && CYGWIN_VERSION_DLL_MAJOR<1007
#define DO_NOTHING_ATEXIT 1
#endif
#endif

using namespace codeGen;

BuilderT *CodeGeneration::Builder = NULL;
llvm::LLVMContext *CodeGeneration::C = NULL;
scope *CodeGeneration::env = NULL;
llvm::Module* CodeGeneration::TheModule = NULL;
llvm::ExecutionEngine* CodeGeneration::TheExecutionEngine = NULL;

CodeGeneration::~CodeGeneration() {}

// Memory manager for MCJIT
class LLIMCJITMemoryManager : public llvm::JITMemoryManager {
public:
  llvm::SmallVector<llvm::sys::MemoryBlock, 16> AllocatedDataMem;
  llvm::SmallVector<llvm::sys::MemoryBlock, 16> AllocatedCodeMem;
  llvm::SmallVector<llvm::sys::MemoryBlock, 16> FreeCodeMem;
  
  LLIMCJITMemoryManager() { }
  ~LLIMCJITMemoryManager();
  
  virtual uint8_t *allocateCodeSection(uintptr_t Size, unsigned Alignment,
                                       unsigned SectionID);
  
  virtual uint8_t *allocateDataSection(uintptr_t Size, unsigned Alignment,
                                       unsigned SectionID);
  
  virtual void *getPointerToNamedFunction(const std::string &Name,
                                          bool AbortOnFailure = true);
  
  // Invalidate instruction cache for code sections. Some platforms with
  // separate data cache and instruction cache require explicit cache flush,
  // otherwise JIT code manipulations (like resolved relocations) will get to
  // the data cache but not to the instruction cache.
  virtual void invalidateInstructionCache();
  
  // The MCJITMemoryManager doesn't use the following functions, so we don't
  // need implement them.
  virtual void setMemoryWritable() {
    llvm_unreachable("Unexpected call!");
  }
  virtual void setMemoryExecutable() {
    llvm_unreachable("Unexpected call!");
  }
  virtual void setPoisonMemory(bool poison) {
    llvm_unreachable("Unexpected call!");
  }
  virtual void AllocateGOT() {
    llvm_unreachable("Unexpected call!");
  }
  virtual uint8_t *getGOTBase() const {
    llvm_unreachable("Unexpected call!");
    return 0;
  }
  virtual uint8_t *startFunctionBody(const llvm::Function *F,
                                     uintptr_t &ActualSize){
    llvm_unreachable("Unexpected call!");
    return 0;
  }
  virtual uint8_t *allocateStub(const llvm::GlobalValue* F, unsigned StubSize,
                                unsigned Alignment) {
    llvm_unreachable("Unexpected call!");
    return 0;
  }
  virtual void endFunctionBody(const llvm::Function *F, uint8_t *FunctionStart,
                               uint8_t *FunctionEnd) {
    llvm_unreachable("Unexpected call!");
  }
  virtual uint8_t *allocateSpace(intptr_t Size, unsigned Alignment) {
    llvm_unreachable("Unexpected call!");
    return 0;
  }
  virtual uint8_t *allocateGlobal(uintptr_t Size, unsigned Alignment) {
    llvm_unreachable("Unexpected call!");
    return 0;
  }
  virtual void deallocateFunctionBody(void *Body) {
    llvm_unreachable("Unexpected call!");
  }
  virtual uint8_t* startExceptionTable(const llvm::Function* F,
                                       uintptr_t &ActualSize) {
    llvm_unreachable("Unexpected call!");
    return 0;
  }
  virtual void endExceptionTable(const llvm::Function *F, uint8_t *TableStart,
                                 uint8_t *TableEnd, uint8_t* FrameRegister) {
    llvm_unreachable("Unexpected call!");
  }
  virtual void deallocateExceptionTable(void *ET) {
    llvm_unreachable("Unexpected call!");
  }
};

uint8_t *LLIMCJITMemoryManager::allocateDataSection(uintptr_t Size,
                                                    unsigned Alignment,
                                                    unsigned SectionID) {
  if (!Alignment)
    Alignment = 16;
  uint8_t *Addr = (uint8_t*)calloc((Size + Alignment - 1)/Alignment, Alignment);
  AllocatedDataMem.push_back(llvm::sys::MemoryBlock(Addr, Size));
  return Addr;
}

uint8_t *LLIMCJITMemoryManager::allocateCodeSection(uintptr_t Size,
                                                    unsigned Alignment,
                                                    unsigned SectionID) {
  if (!Alignment)
    Alignment = 16;
  unsigned NeedAllocate = Alignment * ((Size + Alignment - 1)/Alignment + 1);
  uintptr_t Addr = 0;
  // Look in the list of free code memory regions and use a block there if one
  // is available.
  for (int i = 0, e = FreeCodeMem.size(); i != e; ++i) {
    llvm::sys::MemoryBlock &MB = FreeCodeMem[i];
    if (MB.size() >= NeedAllocate) {
      Addr = (uintptr_t)MB.base();
      uintptr_t EndOfBlock = Addr + MB.size();
      // Align the address.
      Addr = (Addr + Alignment - 1) & ~(uintptr_t)(Alignment - 1);
      // Store cutted free memory block.
      FreeCodeMem[i] = llvm::sys::MemoryBlock((void*)(Addr + Size),
                                        EndOfBlock - Addr - Size);
      return (uint8_t*)Addr;
    }
  }
  
  // No pre-allocated free block was large enough. Allocate a new memory region.
  llvm::sys::MemoryBlock MB = llvm::sys::Memory::AllocateRWX(NeedAllocate, 0, 0);
  
  AllocatedCodeMem.push_back(MB);
  Addr = (uintptr_t)MB.base();
  uintptr_t EndOfBlock = Addr + MB.size();
  // Align the address.
  Addr = (Addr + Alignment - 1) & ~(uintptr_t)(Alignment - 1);
  // The AllocateRWX may allocate much more memory than we need. In this case,
  // we store the unused memory as a free memory block.
  unsigned FreeSize = EndOfBlock-Addr-Size;
  if (FreeSize > 16)
    FreeCodeMem.push_back(llvm::sys::MemoryBlock((void*)(Addr + Size), FreeSize));
  
  // Return aligned address
  return (uint8_t*)Addr;
}

void LLIMCJITMemoryManager::invalidateInstructionCache() {
  for (int i = 0, e = AllocatedCodeMem.size(); i != e; ++i)
    llvm::sys::Memory::InvalidateInstructionCache(AllocatedCodeMem[i].base(),
                                            AllocatedCodeMem[i].size());
}

void *LLIMCJITMemoryManager::getPointerToNamedFunction(const std::string &Name,
                                                       bool AbortOnFailure) {
#if defined(__linux__)
  //===--------------------------------------------------------------------===//
  // Function stubs that are invoked instead of certain library calls
  //
  // Force the following functions to be linked in to anything that uses the
  // JIT. This is a hack designed to work around the all-too-clever Glibc
  // strategy of making these functions work differently when inlined vs. when
  // not inlined, and hiding their real definitions in a separate archive file
  // that the dynamic linker can't see. For more info, search for
  // 'libc_nonshared.a' on Google, or read http://llvm.org/PR274.
  if (Name == "stat") return (void*)(intptr_t)&stat;
  if (Name == "fstat") return (void*)(intptr_t)&fstat;
  if (Name == "lstat") return (void*)(intptr_t)&lstat;
  if (Name == "stat64") return (void*)(intptr_t)&stat64;
  if (Name == "fstat64") return (void*)(intptr_t)&fstat64;
  if (Name == "lstat64") return (void*)(intptr_t)&lstat64;
  if (Name == "atexit") return (void*)(intptr_t)&atexit;
  if (Name == "mknod") return (void*)(intptr_t)&mknod;
#endif // __linux__
  
  const char *NameStr = Name.c_str();
  void *Ptr = llvm::sys::DynamicLibrary::SearchForAddressOfSymbol(NameStr);
  if (Ptr) return Ptr;
  
  // If it wasn't found and if it starts with an underscore ('_') character,
  // try again without the underscore.
  if (NameStr[0] == '_') {
    Ptr = llvm::sys::DynamicLibrary::SearchForAddressOfSymbol(NameStr+1);
    if (Ptr) return Ptr;
  }
  
  if (AbortOnFailure)
    llvm::report_fatal_error("Program used external function '" + Name +
                       "' which could not be resolved!");
  return 0;
}

LLIMCJITMemoryManager::~LLIMCJITMemoryManager() {
  for (unsigned i = 0, e = AllocatedCodeMem.size(); i != e; ++i)
    llvm::sys::Memory::ReleaseRWX(AllocatedCodeMem[i]);
  for (unsigned i = 0, e = AllocatedDataMem.size(); i != e; ++i)
    free(AllocatedDataMem[i].base());
}
////////////////////////////////////////////////////////////////////////////


void CodeGeneration::codeGenerationInit(){
  llvm::InitializeAllTargets();
  llvm::InitializeAllTargetMCs();
  llvm::InitializeAllAsmPrinters();
  llvm::InitializeAllAsmParsers();
  CodeGeneration::TheModule = new llvm::Module("codegen", llvm::getGlobalContext());
  
  std::string ErrorMsg;
  llvm::Module *Mod = CodeGeneration::TheModule;
  if (Mod->MaterializeAllPermanently(&ErrorMsg)) {
    std::cerr << "Could not materialize module.\n";
    std::cerr << "Reason: " << ErrorMsg << "\n";
    exit(1);
  }
  
  llvm::EngineBuilder engineBuilder(Mod);
  engineBuilder.setErrorStr(&ErrorMsg);
  engineBuilder.setEngineKind(llvm::EngineKind::JIT);
  
  // Enable MCJIT
  engineBuilder.setUseMCJIT(true);
  LLIMCJITMemoryManager *JMM = new LLIMCJITMemoryManager();
  engineBuilder.setJITMemoryManager(JMM);
  
  engineBuilder.setOptLevel(llvm::CodeGenOpt::Aggressive);
  
  llvm::ExecutionEngine *EE = engineBuilder.create();
  if (!EE) {
    if (!ErrorMsg.empty())
      std::cerr << "Error creating EE: " << ErrorMsg << "\n";
    else
      std::cerr << "Unknown error creating EE!\n";
    exit(1);
  }
  
  CodeGeneration::TheExecutionEngine = EE;
  // TODO: delete TheExecutionEngine during shutdown  
  
  llvm::TargetMachine *targetMachine = engineBuilder.selectTarget();
  CodeGeneration::TheModule->setDataLayout(targetMachine->getTargetData()->getStringRepresentation());
  CodeGeneration::TheModule->setTargetTriple(targetMachine->getTargetTriple());
}

void* codeGen::getFunctionPointer(string funcName) {
  llvm::Function *func = CodeGeneration::TheModule->getFunction(funcName);
  if(func == NULL) {
    std::cerr << "Function " << funcName << " does not exist.\n";
    exit(1);
  }
  
  llvm::ExecutionEngine *EE = CodeGeneration::TheExecutionEngine;
  // Clear instruction cache before code will be executed.
  // TODO: JMM->invalidateInstructionCache();

  void* fPtr = EE->getPointerToFunction(func);  
  if(!fPtr) {
    std::cerr << "Function pointer is null!\n";
  }
  return fPtr;
}

void CodeGeneration::promote(cval& cv1, cval& cv2) {
  if (cv1.val == NULL || cv2.val == NULL) {
    return;
  }
  
  promoteValToType(cv1, cv2.val->getType(), cv2.is_signed);
  promoteValToType(cv2, cv1.val->getType(), cv1.is_signed);
}

void CodeGeneration::promoteValToType(cval& cv1, llvm::Type *ty2, bool isSigned) {
  llvm::Type* ty1 = (llvm::Type*)cv1.val->getType();
  
  // if either is double, convert to double
  if (ty1->isDoubleTy()) {
    // result will be double
    if (!(ty2->isDoubleTy() || ty2->isFloatTy() || ty2->isIntegerTy())) {
      std::cerr << "Cannot combine double and other" << endl;
    }
  }else if (ty2->isDoubleTy()) {
    // result will be double.
    if (ty1->isDoubleTy()) {
    } else if (ty1->isFloatTy()) {
      cv1.val = Builder->CreateFPExt(cv1.val, ty2);
    } else if (ty1->isIntegerTy()) {
      if (cv1.is_signed) {
        cv1.val = Builder->CreateSIToFP(cv1.val, ty2);
      } else {
        cv1.val = Builder->CreateUIToFP(cv1.val, ty2);
      }
    } else {
      std::cerr << "Cannot combine other and double" << endl;
    }
  }
  // if either is float, convert to float
  else if (ty1->isFloatTy()) {
    // result wil be float
    if (!(ty2->isFloatTy() || ty2->isIntegerTy())) {
      std::cerr << "Cannot combine float and other" << endl;
    }
  }else if (ty2->isFloatTy()) {
    // result will be float.
    if (ty1->isFloatTy()) {
    } else if (ty1->isIntegerTy()) {
      if (cv1.is_signed) {
        cv1.val = Builder->CreateSIToFP(cv1.val, ty2);
      } else {
        cv1.val = Builder->CreateUIToFP(cv1.val, ty2);
      }
    } else {
      std::cerr << "Cannot combine other and float" << endl;
    }
  }
  // otherwise, convert to type of
  // 1) larger type involved, if >= int
  // 2) unsigned type, if two types of equal size >= int
  // 3) int
  else if (ty1->isIntegerTy() && ty2->isIntegerTy()) {
    unsigned size1 = ty1->getPrimitiveSizeInBits();
    unsigned size2 = ty2->getPrimitiveSizeInBits();
    
    if (size1 < 32 && size2 < 32) {
      // convert to int.
      llvm::Type* int_ty = (llvm::Type*)llvm::TypeBuilder<int, false>::get(*C);
      if (cv1.is_signed) {
        cv1.val = Builder->CreateSExt(cv1.val, int_ty);
      } else {
        cv1.val = Builder->CreateZExt(cv1.val, int_ty);
      }
      cv1.is_signed = true;
    } else if (size2 > size1) {
      // convert to type 2
      if (cv1.is_signed) {
        cv1.val = Builder->CreateSExt(cv1.val, ty2);
      } else {
        cv1.val = Builder->CreateZExt(cv1.val, ty2);
      }
      cv1.is_signed = isSigned;
    } else {
      // convert to unsigned, if either is unsigned
      bool rsigned = cv1.is_signed && isSigned;
      cv1.is_signed = rsigned;
    }
  }
}

