/*
 *  returnStmt.h
 *  codeGenFrameWork
 *
 *  Created by umit on 12/28/11.
 *  Copyright 2011 2011 Ozyegin University. All rights reserved.
 *
 */

#ifndef _RETURN_STMT
#define _RETURN_STMT

#include "expressions.h"
#include "stmtCode.h"

namespace codeGen {
  
class ReturnStmt : public StmtCode {
   ExprCode* exp;
   
public:
   ReturnStmt() :
   exp(NULL){
   }
   ~ReturnStmt();

   ReturnStmt(ExprCode* exp) :
      exp(exp){
   }

   virtual void build();
   virtual void print(int indent);
};

}

#endif