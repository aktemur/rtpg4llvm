//
//  breakStmt.cpp
//  codeGenFrameWork
//
//  Created by Baris Aktemur on 30.05.2012.
//  Copyright (c) 2012 2011 Ozyegin University. All rights reserved.
//

#include "breakStmt.h"

using namespace codeGen;

void BreakStmt::build() {
  std::cerr << "Break stmt not supported yet." << std::endl;
  exit(1);
}

void BreakStmt::print(int level) {
  indent(level);
  std::cout << "break;\n";
}