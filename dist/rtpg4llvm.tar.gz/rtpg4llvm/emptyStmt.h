/*
 *  emptyStmt.h
 *  codeGenFrameWork
 *
 *  Created by umit on 12/12/11.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef _EMPTY_STMT
#define _EMPTY_STMT

#include "stmtCode.h"

namespace codeGen {
  
class EmptyStmt : public StmtCode {
public:
   EmptyStmt() {
   }
   virtual void build();
   virtual void print(int level);
};

}

#endif