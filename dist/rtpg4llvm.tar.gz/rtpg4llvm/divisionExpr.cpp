/*
 *  divisionExpr.cpp
 *  codeGenFrameWork
 *
 *  Created by umit on 12/25/11.
 *  Copyright 2011 2011 Ozyegin University. All rights reserved.
 *
 */

#include "divisionExpr.h"

using namespace codeGen;

llvm::Value* DivisionExpr::integerOp(llvm::Value* lval, llvm::Value* rval, bool isSigned) 
{
   if (isSigned) {
      return Builder->CreateSDiv(lval, rval);
   } else {
      return Builder->CreateUDiv(lval, rval);
   }
}

llvm::Value* DivisionExpr::fpOp(llvm::Value* lval, llvm::Value* rval) 
{
   return Builder->CreateFDiv(lval, rval);
}

llvm::Value* DivisionExpr::pointerOp(llvm::Value* lval, llvm::Value* rval) 
{
   std::cerr << "Incompatible types in division." << endl;
   exit(1);
}

void DivisionExpr::printOp() {
  std::cout << " / ";
}