/*
 *  contextUser.h
 *  codeGenFrameWork
 *
 *  Created by umit on 12/11/11.
 *  Copyright 2011 Ozyegin University. All rights reserved.
 *
 */

#ifndef _CODE_GENERATION
#define _CODE_GENERATION

#include "llvm/Module.h"
#include "llvm/LLVMContext.h"
#include "llvm/IRBuilder.h"
#include "llvm/ExecutionEngine/ExecutionEngine.h"
#include "llvm/ExecutionEngine/JIT.h"

#include <string>
#include "scope.h"
#include "cval.h"

typedef llvm::IRBuilder<> BuilderT;

namespace codeGen {
  
class CodeGeneration {  
public:
  virtual ~CodeGeneration();
  static llvm::LLVMContext *C;
  static scope *env;
  static BuilderT *Builder;
  static llvm::Module* TheModule;
  static llvm::ExecutionEngine* TheExecutionEngine;
  
  static void promote(cval& cv1, cval& cv2);
  static void promoteValToType(cval& cv1, llvm::Type *ty2, bool isSigned);
  static void codeGenerationInit();
};

void* getFunctionPointer(string funcName);

}

#endif
