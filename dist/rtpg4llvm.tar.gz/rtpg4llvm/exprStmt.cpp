//
//  exprStmt.cpp
//  codeGenFrameWork
//
//  Created by Baris Aktemur on 13.08.2012.
//  Copyright (c) 2012 2011 Ozyegin University. All rights reserved.
//

#include "exprStmt.h"

using namespace codeGen;

ExprStmt::~ExprStmt() {
  delete e;
}

void ExprStmt::build() {
  e->build();
}

void ExprStmt::print(int level) {
  indent(level);
  e->print();
  std::cout << ";\n";
}

