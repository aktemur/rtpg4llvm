/*
 *  logicalOrExpr.cpp
 *  codeGenFrameWork
 *
 *  Created by umit on 12/25/11.
 *  Copyright 2011 2011 Ozyegin University. All rights reserved.
 *
 */

#include "logicalOrExpr.h"

using namespace codeGen;

llvm::Value* LogicalOrExpr::integerOp(llvm::Value* lval, llvm::Value* rval){
   llvm::Value* cmpLval = Builder->CreateIsNotNull(lval);
   llvm::Value* cmpRval = Builder->CreateIsNotNull(rval);
   
   return Builder->CreateOr(cmpLval, cmpRval);
}

void LogicalOrExpr::printOp() {
  std::cout << " || ";
}