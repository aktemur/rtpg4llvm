//
//  program.h
//  codeGenFrameWork
//
//  Created by Baris Aktemur on 31.05.2012.
//  Copyright (c) 2012 2011 Ozyegin University. All rights reserved.
//

#ifndef codeGenFrameWork_program_h
#define codeGenFrameWork_program_h

#include "compileUnit.h"
#include <vector>

namespace codeGen {
  class Program : public CompileUnit {
  private:
    vector<CompileUnit*> *units;
  public:
    Program(vector<CompileUnit*> *units): units(units) { }
    ~Program();
    virtual void build();
    virtual void print();
    virtual void compile();
  };
  
}


#endif
